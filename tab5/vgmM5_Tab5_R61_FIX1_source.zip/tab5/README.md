# vgmM5 Tab5 (ESP32-P4) — R61 FIX1 / 2026-10-25

日本語 / English

This package contains the independent **Tab5** firmware source. It is not a replacement for the existing `src/` used on AtomS3R, Cardputer or CoreS3.

## 対応

- M5Stack Tab5 (ESP32-P4) / microSD / タッチ操作
- VGM/VGZ および MDX 再生、曲情報、スペクトラム、チャンネル表示
- microSD 内の JPEG / PNG / BMP カバー画像（高速化なし）
- ST7121、ST7123、旧ILI9881Cパネル向けLCD互換オーバーレイ
- 非対応：オンラインモード、USB内蔵ストレージ、キーボード操作

**M5Burner用 Tab5シェアコード:** `rx5H5eOnM45ed4eX`

**クリックノイズは未解決です。** 同じR61 FIX1で激しいクリックノイズが再発し、電源を抜いて放置後に改善した例があります。原因は判明していません。以前のSpeaker待機やFIRの変更がクリックノイズを根本解決したとは扱いません。

## Windows Build-only

1. Install Python and PlatformIO (`pio` in PATH or `%USERPROFILE%\.platformio\penv\Scripts\pio.exe`).
2. Run `RUN_THIS_TAB5_BUILD_ONLY.cmd` from this `tab5` directory.
3. The script verifies the *unmodified* release source SHA-256 manifest, installs pinned dependencies, applies the exact-guarded panel compatibility overlay to the local PlatformIO dependency cache, and builds the firmware.
4. Result: `firmware/.pio/build/tab5-r61-speaker-revert/firmware.bin`.

**No flashing is performed.** The partition map is a historical 16MiB Tab5 installation with an 8MiB app partition and a reserved tail for a separate X68000 installation. Never write this partition table or the entire 16MiB flash to a general user device without a separate backup and layout audit. Never use another device's hardcoded COM/MAC guard. A normal `pio run -t upload` is **not** a supported/verified installation procedure for this package.

The panel overlay is applied at build time to the project-local M5GFX dependency and accepts only verified official source identities for M5GFX 0.2.33/0.2.34. It does not downgrade M5Unified's touch probe or change vgmM5 sound-engine scheduling.

## Local verified build evidence

R61 FIX1 native build succeeded on a Windows ESP32-P4 PlatformIO toolchain; an app-only deployment succeeded to one identity-checked Tab5. Its locally built app binary SHA-256 was:

`099d26838d9c84edc32eb1855489c725e8c5e897e749d29cab509abd140beede`

The M5Burner share code is provided by the project author; the downloadable image behind it was **not independently SHA-checked** against that app-only binary. No claim of uninterrupted long-run playback is made.

## English

This is the locally built and app-only-flashed **R61 FIX1 Tab5** firmware source, not the legacy root `src/` implementation. It plays local VGM/VGZ and MDX from microSD with touch controls and optional cover art. The click-noise issue is unresolved and can recur on the very same firmware; hardware power-state, I2S, codec and amplifier remain hypotheses, not established causes. Run the build-only wrapper. Do not full-flash using the private-development partition layout.

## Credits / licensing

This branch is derived from Layer812/vgmM5. As stated in the original repository, project-authored code is MIT and third-party components retain their own terms (including Mark Adler's `puff.cpp`, mdxtools-related material, Misaki Font, MAME, and ymfm, as applicable). The upstream repository lists credits and licenses: https://github.com/Layer812/vgmM5#license . The ZIP includes no copyrighted music, proprietary ROM images, personal backups or device logs. Do not treat this file as a blanket relicensing of third-party code.
